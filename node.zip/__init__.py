from .styles_csv_loader import *

# 添加中文节点显示名称
NODE_DISPLAY_NAME_MAPPINGS = {
    "Load Styles CSV": "加载风格CSV文件",
    "Multi Styles CSV": "多风格合并节点",
    "Styles Preview": "风格预览"
}